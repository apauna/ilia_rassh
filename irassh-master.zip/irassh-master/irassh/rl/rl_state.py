current_command = None
prev_command = None

current_reward = None

rl_action = None
rl_params = ""
